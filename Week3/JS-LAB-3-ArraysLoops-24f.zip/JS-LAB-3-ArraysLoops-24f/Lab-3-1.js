//LAB 3 - ARRAYS & LOOPS - PART 1

//ARRAY OF FRUITS

var fruits = ["Apple", "Orange", "Banana", "Kiwi", "Pineapple"];

//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX

alert(fruits[2]);
