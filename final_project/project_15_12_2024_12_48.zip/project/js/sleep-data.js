document.addEventListener('DOMContentLoaded', function () {
    // Fetch sleepData from sessionStorage or initialize with default data
    var sleepData = JSON.parse(sessionStorage.getItem('sleepData')) || [];
  
    if (!sleepData || sleepData.length === 0) {
      console.warn('No sleep data found in sessionStorage. Adding default data.');
  
      sleepData = [
        { date: '2024-12-09', sleepTime: '21:00', wakeTime: '06:00', quality: 'Good', mood: 'Energetic' },
        { date: '2024-12-10', sleepTime: '22:00', wakeTime: '05:30', quality: 'Moderate', mood: 'Neutral' },
        { date: '2024-12-11', sleepTime: '23:00', wakeTime: '07:00', quality: 'Bad', mood: 'Tired' },
      ];
  
      sessionStorage.setItem('sleepData', JSON.stringify(sleepData));
    }
  
    var currentWeekOffset = 0; // Tracks the offset of the displayed week
  
    // Initialize the table with the current week's data
    updateTable();
  
    // Event listeners for pagination buttons
    var prevWeekButton = document.getElementById('prev-week');
    var nextWeekButton = document.getElementById('next-week');
  
    if (prevWeekButton) {
      prevWeekButton.addEventListener('click', function () {
        currentWeekOffset--;
        updateTable();
      });
    }
  
    if (nextWeekButton) {
      nextWeekButton.addEventListener('click', function () {
        currentWeekOffset++;
        updateTable();
      });
    }
  
    function updateTable() {
      var tableBody = document.getElementById('data-table-body');
      if (!tableBody) return;
  
      var weekData = getWeekData(sleepData, currentWeekOffset);
  
      tableBody.innerHTML = ''; // Clear existing rows
  
      if (weekData.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="6">No data available for this week.</td></tr>';
      } else {
        weekData.forEach(function (entry, index) {
          var row = document.createElement('tr');
          row.innerHTML = `
            <td>${index + 1}</td>
            <td>${new Date(entry.date).toLocaleDateString('en-US')}</td>
            <td>${entry.sleepTime}</td>
            <td>${entry.wakeTime}</td>
            <td>${entry.quality}</td>
            <td>${entry.mood}</td>
          `;
          tableBody.appendChild(row);
        });
      }
  
      updatePaginationVisibility(sleepData, currentWeekOffset);
    }
  
    function getWeekData(data, offset) {
      var currentWeek = getWeekStartAndEnd(offset);
      return data.filter(function (entry) {
        var entryDate = new Date(entry.date);
        return entryDate >= currentWeek.start && entryDate <= currentWeek.end;
      });
    }
  
    function getWeekStartAndEnd(offset) {
      var now = new Date();
      var currentDay = now.getDay();
      var diffToSunday = -currentDay + offset * 7;
  
      var start = new Date(now.setDate(now.getDate() + diffToSunday));
      start.setHours(0, 0, 0, 0);
  
      var end = new Date(start);
      end.setDate(start.getDate() + 6);
      end.setHours(23, 59, 59, 999);
  
      return { start: start, end: end };
    }
  
    function updatePaginationVisibility(data, offset) {
      var currentWeek = getWeekStartAndEnd(offset);
  
      var hasPreviousData = data.some(function (entry) {
        var entryDate = new Date(entry.date);
        return entryDate < currentWeek.start;
      });
  
      var hasNextData = data.some(function (entry) {
        var entryDate = new Date(entry.date);
        return entryDate > currentWeek.end;
      });
  
      if (prevWeekButton) {
        prevWeekButton.style.display = hasPreviousData ? 'block' : 'none';
      }
  
      if (nextWeekButton) {
        nextWeekButton.style.display = hasNextData ? 'block' : 'none';
      }
    }
  
    // Ensure pagination visibility is updated on initial load
    updatePaginationVisibility(sleepData, currentWeekOffset);
  });
  