// Global variables to store chart instances
var lineChartInstance;
var pieChartInstance;

// Initial hardcoded data (3 entries)
var sleepData = [
  { date: '2024-12-09', sleepTime: '21:00', wakeTime: '06:00', quality: 'Good', mood: 'Energetic' },
  { date: '2024-12-10', sleepTime: '22:00', wakeTime: '05:30', quality: 'Moderate', mood: 'Neutral' },
  { date: '2024-12-11', sleepTime: '23:00', wakeTime: '07:00', quality: 'Bad', mood: 'Tired' },
];

// Check if session storage has user-entered data
if (sessionStorage.getItem('sleepData')) {
  sleepData = JSON.parse(sessionStorage.getItem('sleepData'));
}

$(document).ready(function () {
  // Get current week start and end dates
  function getCurrentWeek() {
    var now = new Date();
    var day = now.getDay();
    var diffToSunday = -day; // Adjust to Sunday
    var firstDayOfWeek = new Date(now.setDate(now.getDate() + diffToSunday));
    firstDayOfWeek.setHours(0, 0, 0, 0);
    var lastDayOfWeek = new Date(firstDayOfWeek);
    lastDayOfWeek.setDate(firstDayOfWeek.getDate() + 6);
    lastDayOfWeek.setHours(23, 59, 59, 999);
    return { start: firstDayOfWeek, end: lastDayOfWeek };
  }

  // Filter sleep data for the current week
  function filterCurrentWeekData(data) {
    var currentWeek = getCurrentWeek();
    return data.filter(function (entry) {
      var entryDate = new Date(entry.date);
      return entryDate >= currentWeek.start && entryDate <= currentWeek.end;
    });
  }

  // Sort sleepData by date
  function sortSleepData() {
    sleepData.sort(function (a, b) {
      return new Date(a.date) - new Date(b.date);
    });
  }

  // Find or update existing record by date
  function updateOrAddData(newEntry) {
    // Convert the input date to UTC
    const inputDateUTC = new Date(newEntry.date).toISOString();
  
    // Find an existing entry with the same UTC date
    const existingEntryIndex = sleepData.findIndex(entry => {
      const entryDateUTC = new Date(entry.date).toISOString();
      return entryDateUTC === inputDateUTC;
    });
  
    if (existingEntryIndex !== -1) {
      // Update the existing entry
      sleepData[existingEntryIndex] = {
        ...sleepData[existingEntryIndex],
        sleepTime: newEntry.sleepTime,
        wakeTime: newEntry.wakeTime,
        quality: newEntry.quality,
        mood: newEntry.mood,
      };
    } else {
      // Add the new entry with the normalized UTC date
      sleepData.push({
        date: inputDateUTC,
        sleepTime: newEntry.sleepTime,
        wakeTime: newEntry.wakeTime,
        quality: newEntry.quality,
        mood: newEntry.mood,
      });
    }
  }
  // Initialize Line Chart
  var lineCtx = document.getElementById('lineChart').getContext('2d');
  function initializeLineChart() {
    if (lineChartInstance) {
      lineChartInstance.destroy();
    }
  
    // Fixed labels for the week (Sunday to Saturday)
    var weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  
    // Create a map to store sleep hours for each day
    var dayHoursMap = {};
    weekDays.forEach(function (day) {
      dayHoursMap[day] = 0; // Initialize all days with 0 hours
    });
  
    // Populate the map with actual data
    sleepData.forEach(function (data) {
      var dayName = new Date(data.date).toLocaleDateString('en-US', { weekday: 'long' });
      if (dayHoursMap.hasOwnProperty(dayName)) {
        dayHoursMap[dayName] = calculateHours(data.sleepTime, data.wakeTime);
      }
    });
  
    // Prepare data for the chart
    var labels = weekDays; // Horizontal axis labels (Sunday to Saturday)
    var hours = weekDays.map(function (day) {
      return dayHoursMap[day]; // Corresponding sleep hours for each day
    });
  
    // Define chart data
    var lineChartData = {
      labels: labels,
      datasets: [
        {
          label: 'Hours of Sleep',
          data: hours,
          borderColor: '#6733cc',
          backgroundColor: 'rgba(103, 51, 204, 0.1)',
          borderWidth: 4,
          tension: 0.3,
          pointBackgroundColor: '#6733cc',
          pointBorderColor: '#FFFFFF',
          pointBorderWidth: 3,
          pointRadius: 8,
        },
      ],
    };
  
    // Define chart options
    var lineChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#ffffff',
          titleColor: '#6733cc',
          bodyColor: '#6d6d6d',
          borderColor: '#6733cc',
          borderWidth: 1,
          titleFont: { family: "'Georgia', serif", size: 14 },
          callbacks: {
            label: function (context) {
              return `Sleep: ${context.parsed.y} hrs`;
            },
          },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            font: { size: 16, family: "'Georgia', serif" },
            color: '#6d6d6d',
          },
        },
        y: {
          grid: { color: 'rgba(103, 51, 204, 0.1)', drawBorder: false },
          ticks: {
            font: { size: 14, family: "'Georgia', serif" },
            color: '#6d6d6d',
            callback: function (value) {
              return `${value} hrs`;
            },
          },
          min: 0,
          max: 10,
        },
      },
    };
  
    // Create the line chart
    lineChartInstance = new Chart(lineCtx, {
      type: 'line',
      data: lineChartData,
      options: lineChartOptions,
    });
  }
  
  
  

  initializeLineChart();
  initializePieChart();
  populateTable();
  updateTotalHours();



  // Update percentage values below the pie chart
  function updatePercentages() {
    // Calculate total entries
    const totalEntries = sleepData.length;

    // Calculate quality counts
    const qualityCounts = { Good: 0, Moderate: 0, Bad: 0 };
    sleepData.forEach(function (entry) {
      if (entry.quality in qualityCounts) {
        qualityCounts[entry.quality]++;
      }
    });

    // Calculate percentages
    const goodPercentage = ((qualityCounts.Good / totalEntries) * 100).toFixed(2);
    const moderatePercentage = ((qualityCounts.Moderate / totalEntries) * 100).toFixed(2);
    const badPercentage = ((qualityCounts.Bad / totalEntries) * 100).toFixed(2);

    // Update DOM elements
    document.getElementById('good-percentage').textContent = `${goodPercentage}%`;
    document.getElementById('moderate-percentage').textContent = `${moderatePercentage}%`;
    document.getElementById('bad-percentage').textContent = `${badPercentage}%`;
  }

  // Initialize Pie Chart
  var pieCtx = document.getElementById('pieChart').getContext('2d');

  function initializePieChart() {
    // Destroy existing pie chart instance if it exists
    if (pieChartInstance) {
      pieChartInstance.destroy();
    }
  
    // Calculate quality counts
    var qualityCounts = { Good: 0, Moderate: 0, Bad: 0 };
  
    // Update counts based on all sleepData
    sleepData.forEach(function (entry) {
      if (entry.quality in qualityCounts) {
        qualityCounts[entry.quality]++;
      }
    });
  
    // Log quality counts for debugging
    console.log('Updated quality counts:', qualityCounts);
  
    // Prepare chart data
    var pieChartData = {
      labels: ['Good', 'Moderate', 'Bad'],
      datasets: [
        {
          data: [qualityCounts.Good, qualityCounts.Moderate, qualityCounts.Bad],
          backgroundColor: ['#6733cc', '#4da8da', '#ff5252'],
          hoverBackgroundColor: ['#5a2eb3', '#399ccf', '#e84545'],
          borderWidth: 1,
        },
      ],
    };
  
    // Define chart options
    var pieChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: true, position: 'bottom' },
      },
    };
  
    // Render the pie chart
    var pieCtx = document.getElementById('pieChart').getContext('2d');
    pieChartInstance = new Chart(pieCtx, {
      type: 'pie',
      data: pieChartData,
      options: pieChartOptions,
    });
    updatePercentages();
    
  }
  
  initializePieChart();
  

  // Toggle Form Popup Visibility
  window.toggleFormPopup = function () {
    var formPopup = document.getElementById('formPopup');
    formPopup.style.display = formPopup.style.display === 'block' ? 'none' : 'block';
  };

 

  // Handle Form Submission
  var form = document.querySelector('form');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
  
    var date = document.getElementById('date').value; // User-entered date
    var sleepTime = document.getElementById('sleep-time').value;
    var wakeTime = document.getElementById('wake-up-time').value;
    var quality = document.getElementById('quality').value;
    var mood = document.getElementById('mood').value;
  
    var newEntry = { date, sleepTime, wakeTime, quality, mood };
  
    // Update or add the new data
    updateOrAddData(newEntry);
  
    // Save updated data to session storage
    sessionStorage.setItem('sleepData', JSON.stringify(sleepData));
  
    // Refresh charts and table
    initializeLineChart();
    initializePieChart();
    updatePercentages(); 
    updateTotalHours();
    populateTable();
  
    // Close the form popup and reset the form
    toggleFormPopup();
    form.reset();
  });
  
  
  
  function updateOrAddData(newEntry) {
    // Normalize the date to YYYY-MM-DD format
    var normalizedDate = new Date(newEntry.date).toISOString().split('T')[0];
  
    // Find an existing entry with the same normalized date
    var existingEntryIndex = sleepData.findIndex(function (entry) {
      var entryDate = new Date(entry.date).toISOString().split('T')[0];
      return entryDate === normalizedDate;
    });
  
    if (existingEntryIndex !== -1) {
      // Update the existing entry
      sleepData[existingEntryIndex] = {
        ...sleepData[existingEntryIndex],
        sleepTime: newEntry.sleepTime,
        wakeTime: newEntry.wakeTime,
        quality: newEntry.quality,
        mood: newEntry.mood,
      };
    } else {
      // Add the new entry if it doesn't exist
      sleepData.push({
        date: normalizedDate,
        sleepTime: newEntry.sleepTime,
        wakeTime: newEntry.wakeTime,
        quality: newEntry.quality,
        mood: newEntry.mood,
      });
    }
  }
  
  
  

  // Clear all data
  function clearData() {
    // Clear the data in memory
    sleepData = [];

    // Remove data from session storage
    sessionStorage.removeItem('sleepData');

    // Reset the charts
    initializeLineChart();
    initializePieChart();
    updatePercentages();
    updateTotalHours();
    populateTable();
    alert('All data has been cleared!');
  }

  // Attach the clearData function to a button
  document.getElementById('clearData').addEventListener('click', clearData);
});
// Function to populate the table body with live data
function populateTable() {
  var tableBody = document.getElementById('data-table-body');
  tableBody.innerHTML = ''; // Clear existing rows

  sleepData.forEach(function (entry, index) {
    var row = document.createElement('tr');

    row.innerHTML = `
      <td>${index + 1}</td>
      <td>${new Date(entry.date).toLocaleDateString('en-US')}</td>
      <td>${entry.sleepTime}</td>
      <td>${entry.wakeTime}</td>
      <td>${entry.quality}</td>
      <td>${entry.mood}</td>
    `;

    tableBody.appendChild(row);
  });
}

// Function to calculate total sleep hours
function updateTotalHours() {
  // Calculate total sleep hours from all entries
  let totalHours = sleepData.reduce((sum, entry) => {
    return sum + calculateHours(entry.sleepTime, entry.wakeTime);
  }, 0);

  // Update the DOM element with the total hours
  document.getElementById('total-hours').textContent = `${totalHours.toFixed(2)} hrs`;
}
// Calculate hours of sleep
function calculateHours(sleepTime, wakeTime) {
  var sleep = new Date(`1970-01-01T${sleepTime}`);
  var wake = new Date(`1970-01-01T${wakeTime}`);
  var hours = (wake - sleep) / (1000 * 60 * 60);
  if (hours < 0) hours += 24; // Handle sleep past midnight
  return hours;
}


document.addEventListener('DOMContentLoaded', () => {
  // Populate table on page load
  if (document.getElementById('data-table-body')) {
    populateTable();
  }
});