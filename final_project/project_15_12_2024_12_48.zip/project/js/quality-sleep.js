document.addEventListener('DOMContentLoaded', function () {
    // Fetch sleepData from sessionStorage or initialize with default data
    var sleepData = JSON.parse(sessionStorage.getItem('sleepData')) || [];

    if (!sleepData || sleepData.length === 0) {
        console.warn('No sleep data found in sessionStorage. Adding default data.');

        sleepData = [
            { date: '2024-12-08', sleepTime: '21:00', wakeTime: '06:00', quality: 'Good', mood: 'Energetic' },
            { date: '2024-12-09', sleepTime: '22:00', wakeTime: '05:30', quality: 'Moderate', mood: 'Neutral' },
            { date: '2024-12-10', sleepTime: '23:00', wakeTime: '07:00', quality: 'Bad', mood: 'Tired' },
            { date: '2024-12-11', sleepTime: '22:30', wakeTime: '06:00', quality: 'Good', mood: 'Energetic' },
            { date: '2024-12-12', sleepTime: '21:45', wakeTime: '06:15', quality: 'Moderate', mood: 'Neutral' },
            { date: '2024-12-13', sleepTime: '23:15', wakeTime: '07:30', quality: 'Bad', mood: 'Tired' },
            { date: '2024-12-14', sleepTime: '22:00', wakeTime: '06:00', quality: 'Good', mood: 'Energetic' },
        ];

        sessionStorage.setItem('sleepData', JSON.stringify(sleepData));
    }

    // Helper function to filter data for the current week
    function getCurrentWeekData(data) {
        const currentDate = new Date();
        const startOfWeek = new Date(currentDate);
        startOfWeek.setDate(currentDate.getDate() - currentDate.getDay()); // Set to Sunday
        startOfWeek.setHours(0, 0, 0, 0); // Start of the day

        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6); // Set to Saturday
        endOfWeek.setHours(23, 59, 59, 999); // End of the day

        return data.filter(entry => {
            const entryDate = new Date(entry.date);
            return entryDate >= startOfWeek && entryDate <= endOfWeek;
        });
    }

    // Filter data for the current week
    var currentWeekData = getCurrentWeekData(sleepData);

    // Prepare data for the graph
    var labels = currentWeekData.map(entry =>
        new Date(entry.date).toLocaleDateString('en-US', { weekday: 'short' })
    );

    var sleepQualityScores = currentWeekData.map(entry => {
        if (entry.quality === 'Good') return 3;
        if (entry.quality === 'Moderate') return 2;
        if (entry.quality === 'Bad') return 1;
        return 0; // Default score for unknown quality
    });

    var moodScores = currentWeekData.map(entry => {
        if (entry.mood === 'Energetic') return 3;
        if (entry.mood === 'Neutral') return 2;
        if (entry.mood === 'Tired') return 1;
        return 0; // Default score for unknown mood
    });

    // Initialize the chart
    var ctx = document.getElementById('qualityMoodChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Quality of Sleep',
                    data: sleepQualityScores,
                    borderColor: 'rgba(103, 51, 204, 1)',
                    backgroundColor: 'rgba(103, 51, 204, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true,
                },
                {
                    label: 'Quality of Mood',
                    data: moodScores,
                    borderColor: 'rgba(77, 168, 218, 1)',
                    backgroundColor: 'rgba(77, 168, 218, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true,
                },
            ],
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                },
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 3,
                    ticks: {
                        stepSize: 1,
                        callback: function (value) {
                            if (value === 3) return 'High';
                            if (value === 2) return 'Moderate';
                            if (value === 1) return 'Low';
                            return '';
                        },
                    },
                },
            },
        },
    });
});
