//LAB 10 - 2 INVENTORY PAGE








	//ADD <tr> MOUSEOVER and MOUSEOUT FUNCTIONS 







	//ADD <tr> CLICK LISTENER 


