//LAB 10 - 1 FAQ PAGE

//Use jQuery to wait for page load



	//Inside of here is your jQuery/JavaScript


	//ADD CLICK EVENT TO <h2>
	
	
	
	
	
	
	//CHANGE <p> BACKGROUND COLOUR ON HOVER





